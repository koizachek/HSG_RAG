"""
Main entry point for the Executive Education RAG Chatbot.
"""
import argparse
import langsmith
from langsmith import traceable
from src.utils.logging import init_logging, get_logger
from config import AVAILABLE_LANGUAGES
from src.cache.cache import Cache
from src.config import config


# Initialize logging
def logging_startup():
    init_logging()
    return get_logger('main_module')


def run_scraper() -> None:
    """
    Run the scraper to collect program data.

    Args:
        use_selenium: Whether to use Selenium for scraping.
    """
    from src.pipeline.pipeline import ImportPipeline
    logger = logging_startup()

    logger.info("Running scraper...")
    ImportPipeline().scrape_website()
    logger.info("Scraping completed.")


def run_importer(sources: list[str]) -> None:
    """Run the data import pipeline."""
    from src.pipeline.pipeline import ImportPipeline
    logger = logging_startup()

    logger.info("Running data import pipeline...")
    ImportPipeline().import_many_documents(sources)
    logger.info("Data processing completed.")


def run_weaviate_command(command: str, backup_id: str = None):
    """Run commands to manipulate the database contents."""
    from src.database.weavservice import WeaviateService
    logger = logging_startup()

    logger.info(f"Running database command {command}")
    if command == 'restore' and not backup_id:
        logger.error("Backup ID is required to initalize the restore process.")

    service = WeaviateService()
    if command == 'backup':
        service._create_backup()

    if command == 'restore':
        service._restore_backup(backup_id)

    if command == 'delete' or command == 'redo':
        service._delete_collections()

    if command == 'init' or command == 'redo':
        service._create_collections()

    if command == 'checkhealth' or command == 'init' or command == 'redo':
        service._checkhealth()


def run_programme_facts_generation() -> None:
    """Regenerate structured programme facts from the current database."""
    from src.rag.programme_facts_generator import generate_programme_facts_json
    logger = logging_startup()

    logger.info("Generating structured programme facts JSON...")
    generate_programme_facts_json()
    logger.info("Programme facts generation completed.")


def clear_cache():
    cache = Cache.get_cache()
    if cache:
        cache.clear_cache()


def run_application(lang: str, cache_mode, cache) -> None:
    """Run the chatbot web application."""
    from src.apps.chat.app import ChatbotApplication
    logger = logging_startup()
    
    Cache.configure(cache_mode, cache)

    logger.info("Starting chatbot web application...")
    app = ChatbotApplication(language=lang)
    app.run()


def run_dbapp() -> None:
    """Run the database application."""
    from src.apps.dbapp.app import DatabaseApplication
    logger = logging_startup()
    logger.info("Starting database application...")
    app = DatabaseApplication()
    app.run()


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="University of St. Gallen Executive Education RAG Chatbot")

    # Add arguments
    parser.add_argument("--scrape", action="store_true",
                        help="Scrapes the data from the HSG website and imports it into the database")
    parser.add_argument("--imports", nargs="+", help="Runs the data importing pipeline for the provided files")

    parser.add_argument("--weaviate", type=str, choices=['init', 'delete', 'redo', 'checkhealth', 'backup', 'restore'],
                        help="Runs different database actions")
    parser.add_argument("--backup-id", type=str, help="Required when calling the --weaviate restore command!")

    parser.add_argument("--cache-mode", type=str, choices=['local', 'cloud', 'dict'], default=config.cache.CACHE_MODE,
                        help="Defines whether to use the local or cloud Redis database or the special python dict as cache")

    parser.add_argument("--cache", action="store_false", help="(De-)activates the caching mechanism")

    parser.add_argument("--clear-cache", action="store_true",
                        help="Clears the cache")

    parser.add_argument("--generate-programme-facts", action="store_true",
                        help="Regenerates structured programme facts JSON from the current database")

    parser.add_argument("--cli", action="store_true", help="Run the chatbot CLI")
    parser.add_argument("--app", type=str, choices=AVAILABLE_LANGUAGES, help="Run the chatbot web application")
    parser.add_argument("--dbapp", action="store_true", help="Run the database management application")

    return parser.parse_args()


def main():
    """Main entry point for the application."""
    args = parse_args()
    
    # Load cache settings with the cache args  
    must_clear_cache = False

    # Check if any argument is provided
    if not any([args.scrape, args.imports, args.weaviate, args.cli, args.cache, args.app, args.dbapp, args.generate_programme_facts]):
        # If no argument is provided, run the chatbot by default
        run_application(cache_mode=args.cache_mode, cache=args.cache)
        return

    # Run the specified components
    if args.scrape:
        must_clear_cache = True
        run_scraper()

    if args.imports:
        must_clear_cache = True
        run_importer(args.imports)

    if args.weaviate:
        if args.weaviate in ["init", "redo", "restore"]:
            must_clear_cache = True
        run_weaviate_command(command=args.weaviate, backup_id=args.backup_id)

    if args.generate_programme_facts:
        must_clear_cache = True
        run_programme_facts_generation()
    
    if args.clear_cache or must_clear_cache:
        clear_cache()

    if args.app:
        run_application(lang=args.app, cache_mode=args.cache_mode, cache=args.cache)

    if args.dbapp:
        run_dbapp()


if __name__ == "__main__":
    main()
