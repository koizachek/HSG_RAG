"""
User Acceptance Tests for Chatbot Improvements

Tests cover:
- TC-EMBA-01/02/03: German speakers, qualification checks, cost inquiries
- TC-IEMBA-01/02: International profile, scheduling
- TC-embaX-01: Career switchers
- Edge cases: numeric input, mixed language, off-topic, aggressive
"""
import pytest
from langchain_core.messages import AIMessage, HumanMessage
from src.apps.chat.app import ChatbotApplication
from src.rag.agent_chain import ExecutiveAgentChain
from src.rag.input_handler import InputHandler
from src.rag.programme_facts import ProgrammeFacts, ProgrammeFactsProvider
from src.rag.response_formatter import ResponseFormatter
from src.rag.scope_guardian import ScopeGuardian
from src.rag.utilclasses import LeadAgentQueryResponse


PROGRAMME_FACT_FIXTURES = {
    "emba": ProgrammeFacts(
        programme="emba",
        source_available=True,
        focus_points=[
            "EMBA HSG focuses on General Management, Leadership and the DACH context.",
        ],
        fit_points=[
            "Hochschulabschluss, 5+ Jahre Berufserfahrung, 3+ Jahre Führungserfahrung und starke Deutschkenntnisse.",
        ],
        timing_points=[
            "Start 14.09.2026, 18 Monate berufsbegleitend, verlängerbar bis 48 Monate, Studiengebühr CHF 77'500.",
        ],
        document_points=[
            "CV, Studienabschluss/Zeugnisse, Führungsverantwortung, Motivation und eine erste Capstone-Idee vorbereiten.",
        ],
        structured={"tuition": "CHF 77'500"},
    ),
    "iemba": ProgrammeFacts(
        programme="iemba",
        source_available=True,
        focus_points=[
            "IEMBA HSG focuses on international management, global peer learning and cross-border leadership.",
        ],
        fit_points=[
            "Hochschulabschluss, 5+ Jahre Berufserfahrung, 3+ Jahre Führungserfahrung und sehr gutes Englisch.",
        ],
        timing_points=[
            "Start 24.08.2026, 18 Monate berufsbegleitend, 10 Kernkurse, 4 Wahlkurse, 4 Wochen Auslandsmodule, Studiengebühr CHF 85'000.",
        ],
        document_points=[
            "CV, Studienabschluss/Zeugnisse, Führungsverantwortung, internationale Zielsetzung und Englisch-Niveau vorbereiten.",
        ],
        structured={"tuition": "CHF 85'000"},
    ),
    "emba_x": ProgrammeFacts(
        programme="emba_x",
        source_available=True,
        focus_points=[
            "emba X focuses on business, technology, innovation and transformation.",
        ],
        fit_points=[
            "Anerkannter Hochschulabschluss, 10+ Jahre Berufserfahrung, 5+ Jahre Führungserfahrung und sehr gutes Englisch.",
        ],
        timing_points=[
            "Finale Bewerbungsfrist 31.10.2026 mit CHF 110'000 Studiengebühr.",
        ],
        document_points=[
            "CV, Studienabschluss/Zeugnisse, Führungsverantwortung, Motivation, Englisch-Niveau und ein Transformationsvorhaben vorbereiten.",
        ],
        structured={"tuition": "CHF 110'000"},
    ),
}


class FakeProgrammeFactsProvider:
    def get_facts(self, programme: str, language: str) -> ProgrammeFacts:
        return PROGRAMME_FACT_FIXTURES.get(programme, ProgrammeFacts(programme=programme))


def attach_fake_programme_facts(agent: ExecutiveAgentChain) -> None:
    agent._programme_facts_provider = FakeProgrammeFactsProvider()


class TestInputHandling:
    """Test numeric input interpretation"""
    
    def test_numeric_experience_input(self):
        """Test that standalone number is interpreted as years of experience"""
        history = [
            {"role": "assistant", "content": "How many years of work experience do you have?"}
        ]
        
        processed, is_valid = InputHandler.process_input("5", history)
        
        assert is_valid
        assert "5 years" in processed.lower()
        assert "experience" in processed.lower()
    
    def test_numeric_age_input(self):
        """Test numeric input interpreted as age"""
        history = [
            {"role": "assistant", "content": "How old are you?"}
        ]
        
        processed, is_valid = InputHandler.process_input("35", history)
        
        assert is_valid
        assert "35" in processed
        assert "years old" in processed.lower() or "age" in processed.lower()
    
    def test_empty_input_validation(self):
        """Test that empty inputs are rejected"""
        processed, is_valid = InputHandler.process_input("", [])
        
        assert not is_valid
        assert processed == ""
    
    def test_whitespace_input_validation(self):
        """Test that whitespace-only inputs are rejected"""
        processed, is_valid = InputHandler.process_input("   ", [])
        
        assert not is_valid


class TestProgrammeFactsProvider:
    def test_extracted_facts_skip_scraped_contact_noise(self):
        raw_context = """
        Vielen Dank für Ihr Interesse an unserem Executive MBA Programm!
        Kontakt Cyra von Müller Senior Recruitment & Admissions Manager EMBA HSG Programm.
        Bewerbungsfristen im Überblick:
        Studiengebühr: CHF 77'500.
        Start: 14.09.2026.
        Dauer: 18 Monate berufsbegleitend.
        """
        facts = ProgrammeFactsProvider(lambda *_args: raw_context).get_facts("emba", "de")

        joined = " ".join(facts.timing_points + facts.fit_points + facts.focus_points)

        assert "CHF 77'500" in joined
        assert "14.09.2026" in joined
        assert "Vielen Dank" not in joined
        assert "Senior Recruitment" not in joined

    def test_document_facts_do_not_use_alumni_motivation_quotes(self):
        raw_context = """
        Ich bin mir ganz sicher, dass ich meinen beruflichen Fortschritt zu einem ganz großen Teil
        der Tools, dem Netzwerk und der Motivation, die ich aus der HSG mitnehmen durfte, zu verdanken habe.
        Bewerbungsunterlagen: CV, Studienabschluss, Zeugnisse und vollständig ausgefüllte Online-Bewerbung.
        """

        facts = ProgrammeFactsProvider(lambda *_args: raw_context).get_facts("iemba", "de")
        joined_documents = " ".join(facts.document_points)

        assert "beruflichen Fortschritt" not in joined_documents
        assert "CV" in joined_documents
        assert "Online-Bewerbung" in joined_documents

    def test_programme_facts_filter_raw_brochure_and_award_fragments(self):
        raw_context = """
        With this programme, two top Swiss institutions join forces to design an innovative Executive Education curriculum.
        They in the form of merit-based tuition incentives are available to candidates.
        The emba X Admissions Committee decides upon the attribution and amount of the incentive award.
        First application deadline: 31 August 2026.
        Final application deadline: 31 October 2026.
        Focus: emba X focuses on business, technology, innovation and transformation.
        Documents: CV, certificates/transcripts and motivation.
        """

        facts = ProgrammeFactsProvider(lambda *_args: raw_context).get_facts("emba_x", "en")
        joined = " ".join(facts.focus_points + facts.timing_points + facts.document_points)

        assert "two top Swiss institutions join forces" not in joined
        assert "incentive award" not in joined
        assert "First application deadline" not in joined
        assert "Final application deadline" not in joined
        assert "business, technology, innovation and transformation" in joined


class TestResponseFormatting:
    """Test response formatting and table removal"""
    
    def test_table_removal(self):
        """Test that markdown tables are converted to bullet points"""
        table_text = """
Here are the programs:

| Program | Duration | Cost |
|---------|----------|------|
| EMBA    | 18 months | CHF 77,500 |
| IEMBA   | 18 months | CHF 85,000 |
        """
        
        formatted = ResponseFormatter.remove_tables(table_text)
        
        # Should not contain table markers
        assert "|" not in formatted
        # Should contain bullet points instead
        assert "•" in formatted or "-" in formatted
    
    def test_response_chunking(self):
        """Test that long responses are chunked"""
        long_text = " ".join(["word"] * 150)  # 150 words
        
        chunked, continuation = ResponseFormatter.chunk_response(long_text, max_words=100)
        
        # Current response should be shorter
        assert ResponseFormatter.count_words(chunked) <= 220  # Allow some buffer
        # Should have continuation indicator
        assert "continue" in chunked.lower() or "more" in chunked.lower()
    
    def test_short_response_no_chunking(self):
        """Test that short responses are not chunked"""
        short_text = "This is a short response."
        
        chunked, continuation = ResponseFormatter.chunk_response(short_text, max_words=200)
        
        assert continuation is None
        assert chunked == short_text

    def test_pending_continuation_is_served_without_new_agent_call(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._pending_continuation = " ".join(["detail"] * 140)

        response = agent._serve_pending_continuation(
            processed_query="ja, mehr details.",
            response_language="de",
        )

        assert response.language == "de"
        assert "Möchten Sie, dass ich mit weiteren Details fortfahre?" in response.response
        assert agent._pending_continuation is not None
        assert agent._conversation_history == []

    def test_continuation_request_handles_punctuation(self):
        agent = object.__new__(ExecutiveAgentChain)

        assert agent._is_continuation_request("ja, mehr details. ")

    def test_programme_overview_covers_all_three_without_chunk_prompt(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._pending_continuation = None
        agent._programme_overview_detail_level = 0

        response = agent._serve_programme_overview(
            processed_query="ich interessiere mich für einen MBA",
            response_language="de",
            detailed=False,
        )

        assert "EMBA HSG" in response.response
        assert "IEMBA HSG" in response.response
        assert "emba X" in response.response
        assert "Bei HSG gibt es drei relevante Executive-MBA-Optionen" in response.response
        assert "Kontak" not in response.response
        assert "Senior Recruitment" not in response.response
        assert "Bewerbungsfristen im Überblick" not in response.response
        assert "Programmfakten unten stammen" not in response.response
        assert "importierten Programmdaten" not in response.response
        assert "Interessieren Sie sich für Kosten" in response.response
        assert "Das Profil klärt" not in response.response
        assert "Möchten Sie, dass ich mit weiteren Details fortfahre?" not in response.response
        assert len(response.response.split()) < 170
        assert response.relevant_programs == ["emba", "iemba", "emba_x"]
        assert isinstance(agent._conversation_history[0], HumanMessage)
        assert isinstance(agent._conversation_history[1], AIMessage)

    def test_profile_context_programme_overview_uses_profile_framing(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._pending_continuation = None
        agent._programme_overview_detail_level = 0

        response = agent._serve_programme_overview(
            processed_query="ich bin chefarzt mit 10 jahren erfahrung",
            response_language="de",
            detailed=False,
            profile_context=True,
        )

        assert "Ihre Angaben helfen vor allem, die Zulassungsebene einzuordnen" in response.response
        assert "EMBA HSG" in response.response
        assert "IEMBA HSG" in response.response
        assert "emba X" in response.response

    def test_generic_leadership_profile_overview_does_not_invent_medical_context(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)
        attach_fake_programme_facts(agent)
        agent._programme_overview_detail_level = 0

        response = agent._serve_programme_overview(
            processed_query="Ich arbeite seit 15 Jahren, davon 7 Jahre als Abteilungsleiter.",
            response_language="de",
            detailed=False,
            profile_context=True,
        )

        assert "Auf Basis Ihrer deutschsprachigen Präferenz und Ihrer Führungserfahrung" in response.response
        assert "**EMBA HSG**" in response.response
        assert "stärkste Fit" in response.response
        assert response.relevant_programs == ["emba"]
        assert agent._conversation_state["suggested_program"] == "emba"
        assert agent._resolve_programmes_for_fact_request("Was kostet das Programm?") == ["emba"]
        assert "EMBA HSG" in response.response
        assert "IEMBA HSG" in response.response
        assert "emba X" in response.response
        forbidden_terms = [
            "ärzt",
            "chefarzt",
            "klinik",
            "spital",
            "medtech",
            "health-it",
            "gesundheits",
        ]
        assert not any(term in response.response.lower() for term in forbidden_terms)

    def test_german_leadership_profile_extractors_support_emba_hsg_recommendation(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        query = "Ich arbeite seit 15 Jahren, davon 7 Jahre als Abteilungsleiter."

        assert agent._extract_experience_years(query) == 15
        assert agent._extract_leadership_years(query) == 7
        assert agent._profile_has_emba_hsg_signal(query, "de")

    def test_international_profile_context_does_not_over_recommend_iemba(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            HumanMessage("I'm looking for an MBA program in Switzerland with international focus."),
            AIMessage("At HSG, there are three relevant Executive MBA options."),
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None
        agent._programme_overview_detail_level = 0

        response = agent._serve_programme_overview(
            processed_query="I have 12 years of experience and 5 years of leadership.",
            response_language="en",
            detailed=False,
            profile_context=True,
        )

        assert "Based on your international focus" not in response.response
        assert "**IEMBA HSG** is the strongest fit" not in response.response
        assert response.relevant_programs == ["emba", "iemba", "emba_x"]
        assert agent._conversation_state["suggested_program"] is None

    def test_technology_profile_context_does_not_over_recommend_emba_x(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            HumanMessage("Ich suche ein MBA-Programm mit Fokus auf Nachhaltigkeit und Digitalisierung."),
            AIMessage("Bei HSG gibt es drei relevante Executive-MBA-Optionen."),
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None
        agent._programme_overview_detail_level = 0

        response = agent._serve_programme_overview(
            processed_query="Ich habe 12 Jahre Erfahrung und 6 Jahre Führung.",
            response_language="de",
            detailed=False,
            profile_context=True,
        )

        assert "Auf Basis Ihres Fokus auf Technologie, Innovation, Transformation oder Nachhaltigkeit" not in response.response
        assert "**emba X**" in response.response
        assert "der stärkste Fit" not in response.response
        assert response.relevant_programs == ["emba", "iemba", "emba_x"]
        assert agent._conversation_state["suggested_program"] is None

    def test_iemba_embax_tech_career_change_guidance_keeps_paths_clear(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            HumanMessage(
                "I'm a software engineer with 9 years of experience. "
                "I want to move into business leadership. Do I qualify for the IEMBA?"
            ),
            AIMessage("IEMBA HSG and emba X can both be relevant."),
            HumanMessage("Would EMBA X be a better fit for my tech background?"),
            AIMessage("Both programmes can be compared."),
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None

        query = "How can I strengthen my application without management experience?"

        assert agent._is_iemba_embax_tech_career_change_request(query)

        response = agent._serve_iemba_embax_tech_career_guidance(
            processed_query=query,
            response_language="en",
        )

        assert "**IEMBA HSG** is the international/general management path" in response.response
        assert "**emba X** is the stronger tech/business/transformation path" in response.response
        assert "admissions should decide" in response.response
        assert "non-standard" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["iemba", "emba_x"]
        assert agent._conversation_state["program_interest"] == ["iemba", "emba_x"]
        assert agent._resolve_programmes_for_fact_request("How much does it cost?") == ["iemba", "emba_x"]
        raw_fragments = [
            "Get in touch",
            "Complete the online",
            "application deadline",
            "incentive award",
            "two top Swiss institutions join forces",
        ]
        assert not any(fragment.lower() in response.response.lower() for fragment in raw_fragments)

    def test_iemba_embax_eligibility_guidance_is_direct_and_handover_ready(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            HumanMessage(
                "I'm a software engineer with 9 years of experience. "
                "I want to move into business leadership. Do I qualify for the IEMBA?"
            ),
            AIMessage("IEMBA HSG and emba X can both be relevant."),
            HumanMessage("How can I strengthen my application without management experience?"),
            AIMessage("Admissions should review your CV."),
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None

        response = agent._serve_iemba_embax_tech_career_guidance(
            processed_query="So am I eligible?",
            response_language="en",
        )

        assert "eligible for an admissions profile review" in response.response
        assert "**emba X** is the stronger thematic fit" in response.response
        assert "handover to admissions now" in response.response
        assert "admissions profile review" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False

    def test_initial_iemba_embax_eligibility_guidance_avoids_premature_handover(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None

        response = agent._serve_iemba_embax_tech_career_guidance(
            processed_query=(
                "I'm a software engineer with 9 years of experience. "
                "I want to move into business leadership. Do I qualify for the IEMBA?"
            ),
            response_language="en",
        )

        assert "experience-length" in response.response
        assert "leadership criterion" in response.response
        assert "**emba X** is also highly relevant" in response.response
        assert "formal handover" not in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False

    def test_iemba_eligibility_assessment_includes_contact_without_widget(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            HumanMessage("Hi, I'm looking for an MBA program in Switzerland with international focus."),
            AIMessage("IEMBA HSG is the international option."),
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None

        query = "Can you assess whether I am eligible?"

        assert agent._is_iemba_eligibility_assessment_request(query)

        response = agent._serve_iemba_eligibility_assessment(
            processed_query=query,
            response_language="en",
        )

        assert "IEMBA HSG" in response.response
        assert "contact Kristin Fuchs / admissions" in response.response
        assert "Final eligibility is decided by admissions" in response.response
        assert response.relevant_programs == ["iemba"]
        assert response.appointment_requested is False
        assert response.show_booking_widget is False

    def test_price_frustration_response_names_current_fees_without_widget(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)

        query = "Warum ist das so teuer?! Das ist doch Wucher!"

        assert agent._is_price_frustration_request(query)

        response = agent._serve_price_frustration_response(
            processed_query=query,
            response_language="de",
        )

        assert "CHF 77'500" in response.response
        assert "CHF 85'000" in response.response
        assert "CHF 110'000" in response.response
        assert "CHF 72'500" not in response.response
        assert "CHF 99'000" not in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False

    def test_bachelor_two_years_is_too_early_for_executive_mba(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None

        query = "Ich habe gerade meinen Bachelor abgeschlossen und 2 Jahre Berufserfahrung. Kann ich mich für den Executive MBA bewerben?"

        assert agent._is_likely_too_early_for_executive_mba(query)

        response = agent._serve_too_early_for_executive_mba(
            processed_query=query,
            response_language="de",
        )

        assert "Executive MBA" in response.response
        assert "zu früh" in response.response
        assert "5 Jahren Berufserfahrung" in response.response
        assert "3 Jahren Führungserfahrung" in response.response
        assert "reguläre **MBA**" in response.response
        assert "Kontakt zu Admissions" in response.response
        assert "https://www.mba.unisg.ch/" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False

    def test_profile_context_update_after_overview_is_not_single_programme_diagnosis(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevant.")
        ]

        assert agent._latest_ai_mentions_multiple_programmes()
        assert agent._is_profile_context_update("10 jahre chefarzt, 5 jahre leadership")
        assert not agent._query_mentions_specific_programme("10 jahre chefarzt, 5 jahre leadership")

    def test_more_details_after_programme_overview_keeps_all_programmes(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevant.")
        ]
        agent._pending_continuation = None
        agent._programme_overview_detail_level = 1

        assert agent._latest_ai_mentions_multiple_programmes()

        response = agent._serve_programme_overview(
            processed_query="mehr details",
            response_language="de",
            detailed=True,
        )

        assert "EMBA HSG" in response.response
        assert "IEMBA HSG" in response.response
        assert "emba X" in response.response
        assert "vorzeitig" not in response.response.lower()
        assert "Möchten Sie, dass ich mit weiteren Details fortfahre?" not in response.response

    def test_embax_preference_moves_to_next_steps_not_repetition(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevant.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)

        assert agent._extract_programme_preference("ich finde emba X besser") == "emba_x"

        response = agent._serve_programme_next_steps(
            processed_query="ich finde emba X besser",
            response_language="de",
            programme="emba_x",
        )

        assert "Fit- und Zulassungsabklärung" in response.response
        assert "31.08.2026" not in response.response
        assert "CHF 99'000" not in response.response
        assert "31.10.2026" in response.response
        assert "Teyuna Giger" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["emba_x"]
        assert agent._conversation_state["handover_requested"] is None
        assert agent._conversation_state["suggested_program"] == "emba_x"

    def test_emba_next_steps_include_programme_specific_details(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
        }
        attach_fake_programme_facts(agent)

        response = agent._serve_programme_next_steps(
            processed_query="ich finde EMBA HSG besser",
            response_language="de",
            programme="emba",
        )

        assert "Cyra von Müller" in response.response
        assert "14.09.2026" in response.response
        assert "CHF 77'500" in response.response
        assert "5+ Jahre Berufserfahrung" in response.response
        assert "3+ Jahre Führungserfahrung" in response.response
        assert response.relevant_programs == ["emba"]

    def test_iemba_next_steps_include_programme_specific_details(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
        }
        attach_fake_programme_facts(agent)

        response = agent._serve_programme_next_steps(
            processed_query="ich finde IEMBA HSG besser",
            response_language="de",
            programme="iemba",
        )

        assert "Kristin Fuchs" in response.response
        assert "24.08.2026" in response.response
        assert "CHF 85'000" in response.response
        assert "10 Kernkurse" in response.response
        assert "4 Wochen Auslandsmodule" in response.response
        assert response.relevant_programs == ["iemba"]

    def test_cost_and_start_follow_up_uses_subagent_from_context(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("Für den **EMBA HSG** ist der nächste Schritt eine Zulassungsabklärung.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        attach_fake_programme_facts(agent)

        assert agent._resolve_programmes_for_fact_request("was kostet der und wann beginnt der") == ["emba"]

        response = agent._serve_programme_fact_request(
            processed_query="was kostet der und wann beginnt der",
            response_language="de",
            programmes=["emba"],
        )

        assert "Kosten" in response.response
        assert "Start" in response.response
        assert "RAG" not in response.response
        assert "Formaler Fit" not in response.response
        assert "Programmunterlagen" not in response.response
        assert "CHF 77'500" in response.response
        assert "14.09.2026" in response.response
        assert response.relevant_programs == ["emba"]

    def test_programme_costs_are_cleaned_without_fit_or_scrape_noise(self):
        class FakeRetrieveTool:
            def __init__(self):
                self.payloads = []

            def invoke(self, payload):
                self.payloads.append(payload)
                program = payload["program"]
                if "Bewerbungsfristen im Überblick" in payload["query"]:
                    return (
                        "Bewerbungsfristen im Überblick\n"
                        "#### IEMBA 14 Programm-Start: 24. August 2026:\n"
                        "- Studiengebühr: CHF 85'000\n"
                        "#### EMBA 71 Programm-Start: 14. September 2026:\n"
                        "- Studiengebühr: CHF 77'500\n"
                        "#### emba X Programm-Start: 2. Februar 2027:\n"
                        "- Finale Bewerbungsfrist Studiengebühr: 31. Oktober 2026 CHF 110'000"
                    )
                contexts = {
                    "emba": (
                        "EMBA HSG Studiengebühr: CHF 77'500."
                    ),
                    "iemba": (
                        "IEMBA HSG Studiengebühr: CHF 85'000.\n"
                        "St.Gallen, Schweiz 5 Tage Start with you: Find your Leadership Identity Wahlkurs 5 Tage."
                    ),
                    "emba x": (
                        "emba X Studiengebühr: CHF 110'000 bis zur finalen Bewerbungsfrist 31.10.2026."
                    ),
                }
                return contexts[program]

        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._retrieve_context_tool = FakeRetrieveTool()
        attach_fake_programme_facts(agent)

        response = agent._serve_programme_fact_request(
            processed_query="was kosten die programme?",
            response_language="de",
            programmes=["emba", "iemba", "emba_x"],
        )

        assert len(agent._retrieve_context_tool.payloads) == 0
        assert "EMBA HSG" in response.response
        assert "IEMBA HSG" in response.response
        assert "emba X" in response.response
        assert "CHF 77'500" in response.response
        assert "CHF 85'000" in response.response
        assert "CHF 99'000" not in response.response
        assert "CHF 110'000" in response.response
        assert "Formaler Fit" not in response.response
        assert "aus derselben Quelle" not in response.response
        assert "Programmunterlagen" not in response.response
        assert "Bewerbungsfristen im Überblick" not in response.response
        assert "Start with you" not in response.response

    def test_cost_fact_formatting_uses_only_final_deadline_price(self):
        agent = object.__new__(ExecutiveAgentChain)

        response = agent._format_requested_fact_block(
            "EMBA HSG",
            "cost",
            [
                "29. Juni 2026: CHF 72'500",
                "10. August 2026: CHF 77'500",
            ],
            "de",
        )

        assert "CHF 72'500" not in response
        assert "CHF 77'500" in response

    def test_cost_fact_extraction_uses_current_uat_price_over_retrieved_stale_price(self):
        agent = object.__new__(ExecutiveAgentChain)
        attach_fake_programme_facts(agent)

        values = agent._extract_values_for_fact_category(
            [
                "EMBA HSG Studiengebühr CHF 72'500.",
                "Zusätzliche Gebühr CHF 3'000.",
                "Aktuelle Studiengebühr CHF 77'500.",
            ],
            "cost",
            "de",
            "emba",
        )

        assert values == ["CHF 77'500"]

    def test_cost_fact_extraction_uses_fallback_only_without_database_price(self):
        agent = object.__new__(ExecutiveAgentChain)

        values = agent._extract_values_for_fact_category(
            ["EMBA HSG Studiengebühr wird im Beratungsgespräch bestätigt."],
            "cost",
            "de",
            "emba",
        )

        assert values == []

    def test_single_programme_deadline_info_uses_rag_not_booking(self):
        class FakeRetrieveTool:
            def __init__(self):
                self.payloads = []

            def invoke(self, payload):
                self.payloads.append(payload)
                return (
                    "1. Setzen Sie sich mit uns in Verbindung - senden Sie uns Ihren Lebenslauf, "
                    "um zu erfahren, ob Ihr Profil zu unserem Programm passt 2. Vollständig "
                    "ausgefüllte Online-Bewerbung 3. Absolvierung des Online-Assessments "
                    "(nach Einladung) 4. Online-Interview 5. Finaler Entscheid durch den "
                    "Zulassungsausschuss. Unser Bewerbungsprozess ist kostenlos.\n"
                    "#### EMBA 71 Programm-Start: 14. September 2026:\n"
                    "- 1. Bewerbungsfrist Studiengebühr: 29. Juni 2026 CHF 72'500\n"
                    "- Finale Bewerbungsfrist Studiengebühr: 10. August 2026 CHF 77'500"
                )

        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._retrieve_context_tool = FakeRetrieveTool()

        query = "Welche Bewerbungsfristen gelten für den EMBA HSG?"
        assert agent._resolve_application_programmes(query) == []
        assert agent._resolve_programmes_for_fact_request(query) == ["emba"]
        assert agent._requested_fact_categories(query, "de") == ["deadline"]

        response = agent._serve_programme_fact_request(
            processed_query=query,
            response_language="de",
            programmes=["emba"],
        )

        assert len(agent._retrieve_context_tool.payloads) == 1
        assert "Bewerbungsfrist" in response.response
        assert "29\\. Juni 2026" in response.response
        assert "10\\. August 2026" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert "Terminoptionen" not in response.response

    def test_specific_how_to_apply_routes_to_application_next_steps_without_widget(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)

        query = "Wie kann ich mich für emba x bewerben?"

        assert agent._resolve_programmes_for_fact_request(query) == []
        assert agent._resolve_application_programmes(query) == ["emba_x"]

        response = agent._serve_application_next_steps(
            processed_query=query,
            response_language="de",
            programmes=["emba_x"],
        )

        assert "Bewerbung zum **emba X**" in response.response
        assert "Teyuna Giger" in response.response
        assert "31.08.2026" not in response.response
        assert "CHF 99'000" not in response.response
        assert "31.10.2026" in response.response
        assert "CHF 110'000" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["emba_x"]

    def test_explicit_booking_request_stays_out_of_fact_routing(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        assert agent._resolve_programmes_for_fact_request(
            "Ich möchte einen Termin für EMBA HSG buchen."
        ) == []

    def test_retrieve_context_via_tool_invokes_langchain_tool(self):
        class FakeRetrieveTool:
            def __init__(self):
                self.payload = None

            def invoke(self, payload):
                self.payload = payload
                return "retrieved context"

        agent = object.__new__(ExecutiveAgentChain)
        fake_tool = FakeRetrieveTool()
        agent._retrieve_context_tool = fake_tool

        result = agent._retrieve_context_via_tool(
            query="Studiengebühr Startdatum",
            program="emba",
            language="de",
        )

        assert result == "retrieved context"
        assert fake_tool.payload == {
            "query": "Studiengebühr Startdatum",
            "program": "emba",
            "language": "de",
        }

    def test_retrieve_context_applies_program_filter(self):
        class FakeDoc:
            properties = {"body": "filtered context"}

        class FakeResponse:
            objects = [FakeDoc()]

        class FakeDbService:
            def __init__(self):
                self.calls = []

            def query(self, query, lang, property_filters=None, limit=None):
                self.calls.append(
                    {
                        "query": query,
                        "lang": lang,
                        "property_filters": property_filters,
                        "limit": limit,
                    }
                )
                return FakeResponse(), 0.0

        agent = object.__new__(ExecutiveAgentChain)
        fake_db = FakeDbService()
        agent._dbservice = fake_db
        agent._initial_language = "en"

        result = agent._retrieve_context(
            query="tuition admissions",
            program="emba x",
            language="en",
        )

        assert result == "filtered context"
        assert fake_db.calls[0]["property_filters"] == {"programs": ["emba_x"]}

    def test_application_question_after_programme_choice_keeps_booking_off(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("Für emba X sind die nächsten Schritte ein Fit- und Zulassungsgespräch.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": "emba_x",
            "program_interest": [],
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)

        assert agent._resolve_application_programmes("Wie läuft die Bewerbung ab?") == ["emba_x"]

        response = agent._serve_application_next_steps(
            processed_query="Wie läuft die Bewerbung ab?",
            response_language="de",
            programmes=["emba_x"],
        )

        assert "Bewerbung zum **emba X**" in response.response
        assert "Teyuna Giger" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["emba_x"]

    def test_application_process_follow_up_adds_details_without_repeating_widget(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": "emba_x",
            "program_interest": ["emba_x"],
        }
        agent._pending_continuation = None
        attach_fake_programme_facts(agent)

        first_response = agent._serve_application_next_steps(
            processed_query="Wie bewerbe ich mich?",
            response_language="de",
            programmes=["emba_x"],
        )

        assert agent._previous_response_was_application_next_step()
        assert agent._is_application_process_detail_request("Wie läuft der Prozess?")
        assert agent._resolve_known_application_programmes("Wie läuft der Prozess?") == ["emba_x"]

        second_response = agent._serve_application_process_details(
            processed_query="Wie läuft der Prozess?",
            response_language="de",
            programmes=["emba_x"],
        )

        assert second_response.response != first_response.response
        assert "Unterlagen vorbereiten" in second_response.response
        assert "31.08.2026" not in second_response.response
        assert "CHF 99'000" not in second_response.response
        assert "31.10.2026" in second_response.response
        assert second_response.appointment_requested is False
        assert second_response.show_booking_widget is False
        assert second_response.relevant_programs == ["emba_x"]

    def test_emba_application_process_details_include_start_fee_and_requirements(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("Für die Bewerbung zum **EMBA HSG** ist der nächste sinnvolle Schritt ein Zulassungsgespräch.")
        ]
        agent._conversation_state = {
            "handover_requested": True,
            "suggested_program": "emba",
            "program_interest": ["emba"],
        }
        attach_fake_programme_facts(agent)

        response = agent._serve_application_process_details(
            processed_query="Wie läuft der Prozess?",
            response_language="de",
            programmes=["emba"],
        )

        assert "EMBA HSG" in response.response
        assert "14.09.2026" in response.response
        assert "CHF 77'500" in response.response
        assert "5+ Jahre Berufserfahrung" in response.response
        assert "3+ Jahre Führungserfahrung" in response.response
        assert "Capstone" in response.response
        assert response.show_booking_widget is False

    def test_iemba_application_process_details_include_start_fee_and_requirements(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("Für die Bewerbung zum **IEMBA HSG** ist der nächste sinnvolle Schritt ein Zulassungsgespräch.")
        ]
        agent._conversation_state = {
            "handover_requested": True,
            "suggested_program": "iemba",
            "program_interest": ["iemba"],
        }
        attach_fake_programme_facts(agent)

        response = agent._serve_application_process_details(
            processed_query="Welche Unterlagen und Fristen?",
            response_language="de",
            programmes=["iemba"],
        )

        assert "IEMBA HSG" in response.response
        assert "24.08.2026" in response.response
        assert "CHF 85'000" in response.response
        assert "5+ Jahre Berufserfahrung" in response.response
        assert "3+ Jahre Führungserfahrung" in response.response
        assert "sehr gutes Englisch" in response.response
        assert response.show_booking_widget is False

    def test_embax_user_interest_is_not_misclassified_as_emba_hsg(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "session_id": "session-1",
            "user_id": "session-1",
            "user_language": "de",
            "user_name": None,
            "experience_years": None,
            "leadership_years": None,
            "field": None,
            "interest": None,
            "qualification_level": None,
            "program_interest": [],
            "suggested_program": None,
            "handover_requested": None,
            "topics_discussed": [],
            "preferences_known": False,
        }

        agent._update_conversation_state(
            "Ich interessiere mich für den EMBA x.",
            "Gerne, emba X ist das Joint Degree mit ETH Zürich und Universität St.Gallen.",
        )

        assert agent._conversation_state["program_interest"] == ["emba_x"]
        assert agent._conversation_state["suggested_program"] == "emba_x"
        assert agent._resolve_application_programmes("Wie läuft die Bewerbung?") == ["emba_x"]

        response = agent._serve_application_next_steps(
            processed_query="Wie läuft die Bewerbung?",
            response_language="de",
            programmes=["emba_x"],
        )

        assert "Teyuna Giger" in response.response
        assert response.relevant_programs == ["emba_x"]

    def test_later_embax_selection_overrides_stale_emba_suggestion(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "session_id": "session-1",
            "user_id": "session-1",
            "user_language": "de",
            "user_name": None,
            "experience_years": None,
            "leadership_years": None,
            "field": None,
            "interest": None,
            "qualification_level": None,
            "program_interest": [],
            "suggested_program": "emba",
            "handover_requested": None,
            "topics_discussed": [],
            "preferences_known": False,
        }

        assert agent._extract_programme_preference("ich denke der emba X ist der beste") == "emba_x"

        agent._update_conversation_state(
            "ich denke der emba X ist der beste",
            "Dann sind die nächsten Schritte für emba X relevant.",
        )

        assert agent._conversation_state["program_interest"] == ["emba_x"]
        assert agent._conversation_state["suggested_program"] == "emba_x"
        assert agent._resolve_application_programmes("wie bewerbe ich mich?") == ["emba_x"]

    def test_assistant_multi_programme_text_does_not_set_user_programme_interest(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "session_id": "session-1",
            "user_id": "session-1",
            "user_language": "de",
            "user_name": None,
            "experience_years": None,
            "leadership_years": None,
            "field": None,
            "interest": None,
            "qualification_level": None,
            "program_interest": [],
            "suggested_program": None,
            "handover_requested": None,
            "topics_discussed": [],
            "preferences_known": False,
        }

        agent._update_conversation_state(
            "Was ist ein Capstone-Projekt?",
            "Das kann im EMBA HSG, IEMBA HSG oder emba X relevant sein.",
        )

        assert agent._conversation_state["program_interest"] == []
        assert agent._conversation_state["suggested_program"] is None

    def test_assistant_overview_text_does_not_create_embax_suggestion(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "session_id": "session-1",
            "user_id": "session-1",
            "user_language": "de",
            "user_name": None,
            "experience_years": None,
            "leadership_years": None,
            "field": None,
            "interest": None,
            "qualification_level": None,
            "program_interest": [],
            "suggested_program": None,
            "handover_requested": None,
            "topics_discussed": [],
            "preferences_known": False,
        }

        agent._update_conversation_state(
            "ich interessiere mich für einen MBA",
            (
                "EMBA HSG, IEMBA HSG und emba X sind relevant. "
                "emba X passt zu Technologie, Innovation und Transformation."
            ),
        )

        assert agent._conversation_state["interest"] is None
        assert agent._conversation_state["program_interest"] == []
        assert agent._conversation_state["suggested_program"] is None

    def test_application_timing_after_multi_programme_overview_is_fact_request_not_embax_booking(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevante Optionen.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }
        attach_fake_programme_facts(agent)

        programmes = agent._resolve_programmes_for_fact_request("wann soll ich mich denn bewerben?")
        assert programmes == [
            "emba",
            "iemba",
            "emba_x",
        ]

        response = agent._serve_programme_fact_request(
            processed_query="wann soll ich mich denn bewerben?",
            response_language="de",
            programmes=programmes,
        )

        assert response.show_booking_widget is False
        assert response.appointment_requested is False
        assert response.relevant_programs == ["emba", "iemba", "emba_x"]

    def test_each_programme_start_dates_ignore_stale_embax_suggestion(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevante Optionen.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": "emba_x",
            "program_interest": ["emba_x"],
        }

        programmes = agent._resolve_programmes_for_fact_request(
            "was sind die startdaten für die programme jeweils?"
        )

        assert programmes == ["emba", "iemba", "emba_x"]

    def test_empty_programme_facts_are_not_cached(self):
        calls = []

        def fake_retrieve(query, program, language):
            calls.append((query, program, language))
            return ""

        provider = ProgrammeFactsProvider(fake_retrieve)

        provider.get_facts("emba", "de")
        provider.get_facts("emba", "de")

        assert len(calls) == 2

    def test_application_question_with_specific_programme_shows_correct_advisor(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        programmes = agent._resolve_application_programmes(
            "Wie bewerbe ich mich für den IEMBA HSG?"
        )

        assert programmes == ["iemba"]

        response = agent._serve_application_next_steps(
            processed_query="Wie bewerbe ich mich für den IEMBA HSG?",
            response_language="de",
            programmes=programmes,
        )

        assert "IEMBA HSG" in response.response
        assert "Kristin Fuchs" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["iemba"]

    def test_general_application_question_after_multi_programme_overview_keeps_booking_off(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevant.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        programmes = agent._resolve_application_programmes("Wie läuft die Bewerbung?")

        assert programmes == ["emba", "iemba", "emba_x"]

        response = agent._serve_application_next_steps(
            processed_query="Wie läuft die Bewerbung?",
            response_language="de",
            programmes=programmes,
        )

        assert "Zielprogramm" in response.response
        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert response.relevant_programs == ["emba", "iemba", "emba_x"]

    def test_next_application_steps_question_does_not_request_booking(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("EMBA HSG, IEMBA HSG und emba X sind relevante Optionen.")
        ]
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        programmes = agent._resolve_application_programmes(
            "Was sind die nächsten Schritte im Bewerbungsprozess?"
        )

        assert programmes == ["emba", "iemba", "emba_x"]

        response = agent._serve_application_next_steps(
            processed_query="Was sind die nächsten Schritte im Bewerbungsprozess?",
            response_language="de",
            programmes=programmes,
        )

        assert response.appointment_requested is False
        assert response.show_booking_widget is False
        assert "Terminoptionen" not in response.response
        assert "Kontaktdaten" not in response.response

    def test_explicit_booking_request_stays_out_of_application_route(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = []
        agent._conversation_state = {
            "handover_requested": None,
            "suggested_program": None,
            "program_interest": [],
        }

        assert agent._resolve_application_programmes(
            "Ich möchte einen Termin zum Bewerbungsprozess für den EMBA HSG buchen."
        ) == []

    def test_multi_programme_application_process_details_include_all_programmes(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [
            AIMessage("Für den Bewerbungsschritt sollte zuerst geklärt werden, welches Programm Sie konkret ansteuern.")
        ]
        agent._conversation_state = {
            "handover_requested": True,
            "suggested_program": None,
            "program_interest": [],
        }
        attach_fake_programme_facts(agent)

        response = agent._serve_application_process_details(
            processed_query="Wie läuft der Prozess?",
            response_language="de",
            programmes=["emba", "iemba", "emba_x"],
        )

        assert "EMBA HSG" in response.response
        assert "14.09.2026" in response.response
        assert "CHF 77'500" in response.response
        assert "IEMBA HSG" in response.response
        assert "24.08.2026" in response.response
        assert "CHF 85'000" in response.response
        assert "emba X" in response.response
        assert "31.08.2026" not in response.response
        assert "CHF 99'000" not in response.response
        assert "31.10.2026" in response.response
        assert response.show_booking_widget is False

    def test_reset_conversation_state_clears_profile_and_history(self):
        agent = object.__new__(ExecutiveAgentChain)
        agent._conversation_history = [HumanMessage("ich bin chefarzt")]
        agent._pending_continuation = "more"
        agent._programme_overview_detail_level = 2
        agent._fallback_counters = {
            "invalid_input": 1,
            "aggressive": 1,
            "scope_violations": {"weather": 1},
        }
        agent._conversation_state = {
            "session_id": "session-1",
            "user_id": "session-1",
            "user_language": "de",
            "user_name": None,
            "experience_years": 10,
            "leadership_years": 5,
            "field": "medicine",
            "interest": "emba",
            "qualification_level": None,
            "program_interest": ["emba_x"],
            "suggested_program": "emba_x",
            "handover_requested": True,
            "topics_discussed": ["profile"],
            "preferences_known": True,
        }

        agent.reset_conversation_state()

        assert agent._conversation_history == []
        assert agent._pending_continuation is None
        assert agent._programme_overview_detail_level == 0
        assert agent._fallback_counters == {
            "invalid_input": 0,
            "aggressive": 0,
            "scope_violations": {},
        }
        assert agent._conversation_state["experience_years"] is None
        assert agent._conversation_state["field"] is None
        assert agent._conversation_state["suggested_program"] is None
        assert agent._conversation_state["program_interest"] == []

    def test_chat_resets_stale_agent_when_visible_history_is_empty(self):
        class FakeAgent:
            def __init__(self):
                self._conversation_history = [HumanMessage("ich bin chefarzt")]
                self.reset_called = False

            def reset_conversation_state(self):
                self.reset_called = True
                self._conversation_history = []

            def query(self, message):
                assert self.reset_called
                assert self._conversation_history == []
                return LeadAgentQueryResponse(response="fresh answer", language="de")

        app = ChatbotApplication.__new__(ChatbotApplication)
        app._language = "de"
        agent = FakeAgent()

        answers, returned_agent = app._chat("ich interessiere mich für einen mba", [], agent)

        assert answers == ["fresh answer"]
        assert returned_agent is agent
        assert agent.reset_called is True

    def test_chatbot_application_constructs_with_clear_handler(self):
        app = ChatbotApplication(language="de")

        assert app.app is not None


class TestScopeGuardian:
    """Test scope checking and redirection"""
    
    def test_on_topic_query(self):
        """Test that MBA-related queries are on-topic"""
        queries = [
            "What are the admission requirements for EMBA?",
            "How much does the program cost?",
            "What is the difference between EMBA and IEMBA?"
        ]
        
        for query in queries:
            query = ''.join(e for e in query if e.isalnum() or e == " ")
            scope = ScopeGuardian.check_scope(query, 'en')
            assert scope == 'on_topic'
    
    def test_off_topic_detection(self):
        """Test that off-topic queries are detected"""
        off_topic_queries = [
            "What's the weather today?",
            "Can you recommend a restaurant?",
            "Who won the sports match?"
        ]
        
        for query in off_topic_queries:
            query = ''.join(e for e in query if e.isalnum() or e == " ")
            scope = ScopeGuardian.check_scope(query, 'en')
            assert scope == 'off_topic'

    def test_off_topic_redirect_names_programme_paths(self):
        response = ScopeGuardian.get_redirect_message("off_topic", "de")

        assert "Restaurants" in response
        assert "EMBA HSG" in response
        assert "IEMBA HSG" in response
        assert "emba X" in response
        assert "Programme vergleichen" in response
    
    def test_financial_planning_detection(self):
        """Test that detailed financial requests are flagged"""
        financial_queries = [
            "Can you help me create a payment plan?",
            "How do I apply for a bank loan?",
            "I need a detailed budget for the program"
        ]
        
        for query in financial_queries:
            query = ''.join(e for e in query if e.isalnum() or e == " ")
            scope = ScopeGuardian.check_scope(query, 'en')
            assert scope == 'financial_planning'
    
    def test_aggressive_detection(self):
        """Test that aggressive language is detected"""
        aggressive_queries = [
            "This is stupid",
            "You're useless",
            "This chatbot is terrible"
        ]
        
        for query in aggressive_queries:
            query = ''.join(e for e in query if e.isalnum() or e == " ")
            scope = ScopeGuardian.check_scope(query, 'en')
            assert scope == 'aggressive'
    
    def test_redirect_message_language(self):
        """Test that redirect messages match requested language"""
        en_redirect = ScopeGuardian.get_redirect_message('off_topic', 'en')
        de_redirect = ScopeGuardian.get_redirect_message('off_topic', 'de')
        
        # English should contain English words
        assert any(word in en_redirect.lower() for word in ['help', 'programs', 'questions'])
        # German should contain German words
        assert any(word in de_redirect.lower() for word in ['hilfe', 'programm', 'fragen'])
    
    def test_escalation_logic(self):
        """Test that repeated violations trigger escalation"""
        # First off-topic -> no escalation
        should_escalate, _ = ScopeGuardian.should_escalate(
            "What's the weather",
            'off_topic',
            attempt_count=1
        )
        assert not should_escalate
        
        # Second off-topic -> escalate
        should_escalate, escalation_type = ScopeGuardian.should_escalate(
            "What's the weather",
            'off_topic',
            attempt_count=2
        )
        assert should_escalate
        assert escalation_type == 'escalate_off_topic'
        
        # Aggressive -> escalation if attempt_count >= 2
        should_escalate, escalation_type = ScopeGuardian.should_escalate(
            "You're useless",
            'aggressive',
            attempt_count=2
        )
        assert should_escalate
        assert escalation_type == 'escalate_aggressive'


class TestLanguageLocking:
    """Test language detection and locking"""
    
    def test_language_locked_after_first_message(self):
        """Test that language is locked after first user message"""
        agent = ExecutiveAgentChain(language='en')
        
        # First query in German
        response = agent.query("Hallo, ich interessiere mich für das EMBA Programm").response
        
        # Language should now be locked to German
        assert agent._stored_language == 'de'
        assert agent._conversation_state['user_language'] == 'de'
        
        # Subsequent English query should still get German response
        # (language is locked)
        assert agent._stored_language == 'de'


class TestUserAcceptanceScenarios:
    """Test complete user interaction scenarios"""
    
    def test_tc_emba_01_german_speaker(self):
        """TC-EMBA-01: German speaker asking about qualifications"""
        agent = ExecutiveAgentChain(language='de')
        agent.generate_greeting()
        
        # User asks about requirements in German
        response = agent.query("Welche Voraussetzungen brauche ich für das EMBA HSG Programm?").response
        
        # Response should be in German
        assert any(word in response.lower() for word in ['bachelor', 'master', 'jahre', 'erfahrung'])
        # Should not be overly long
        word_count = len(response.split())
        assert word_count < 200, f"Response too long: {word_count} words"
        # Should not contain tables
        assert '|' not in response
    
    def test_tc_emba_03_cost_inquiry(self):
        """TC-EMBA-03: Cost inquiry"""
        agent = ExecutiveAgentChain(language='de')
        agent.generate_greeting()

        response = agent.query("Was kostet das EMBA HSG Programm?").response

        # Should mention programme pricing
        assert 'CHF' in response or 'Kosten' in response.lower()
        # Should mention the current EMBA HSG tuition figure.
        assert "77" in response
        # Should be concise
        word_count = len(response.split())
        assert word_count < 150


class TestEdgeCases:
    """Test edge cases and error handling"""
    
    def test_mixed_language_input(self):
        """Test handling of mixed language input"""
        agent = ExecutiveAgentChain(language='en')
        
        # Mixed language should be handled gracefully
        response = agent.query("Hello I want to know über das EMBA program").response
        
        # Should receive a response (not crash)
        assert len(response) > 0
        assert isinstance(response, str)
    
    def test_very_short_input(self):
        """Test single character or word inputs"""
        agent = ExecutiveAgentChain(language='en')

        response = agent.query("hi").response
        
        # Should handle gracefully
        assert len(response) > 0
    
    def test_special_characters(self):
        """Test handling of special characters"""
        agent = ExecutiveAgentChain(language='en')

        response = agent.query("Cost??? $$$ EMBA HSG!!!!").response
        
        # Should handle and respond appropriately
        assert len(response) > 0
        assert 'CHF' in response or 'cost' in response.lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
